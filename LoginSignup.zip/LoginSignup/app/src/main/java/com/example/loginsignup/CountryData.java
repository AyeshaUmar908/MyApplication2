package com.example.loginsignup;

public class CountryData {
    public static final String[] countryNames = { "Pakistan"};

    public static final String[] countryAreaCodes = {" 92"};
}
