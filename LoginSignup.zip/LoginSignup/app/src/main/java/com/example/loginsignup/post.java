package com.example.loginsignup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.example.myapplication2.TaskPostActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class post extends AppCompatActivity {

    private Button btnh;
    private Button btnw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);


        btnh = findViewById(R.id.button3);
        btnh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openHirer();
            }

            private void openHirer() {
                Intent intent = new Intent(post.this, TaskPostActivity.class);
                startActivity(intent);

            }
        });


    }
}