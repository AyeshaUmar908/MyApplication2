package com.example.loginsignup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class signup extends AppCompatActivity {

    private EditText etemail, etpassword, etconfirmpassword;
    private String email, password, confirmpassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        etemail = findViewById(R.id.etemail);
        etpassword = findViewById(R.id.etpassword);
        etconfirmpassword = findViewById(R.id.etconfirmpassword);

    }

    public void btnsignupClick(View view) {
        email = etemail.getText().toString().trim();
        password = etpassword.getText().toString().trim();
        confirmpassword = etconfirmpassword.getText().toString().trim();
        if (email.equals("")) {
            etemail.setError("Enter Email");
        } else if (password.equals("")) {
            etpassword.setError("Enter Password");
        } else if (confirmpassword.equals("")) {
            etconfirmpassword.setError("confirm password");
        } else if (!confirmpassword.equals(password)) {
            etconfirmpassword.setError(" password not correct");
        } else {

            FirebaseAuth mAuth = FirebaseAuth.getInstance();
            mAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                user user = new user(email, password, confirmpassword);

                                FirebaseDatabase.getInstance().getReference("user")
                                        .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                        .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            Toast.makeText(signup.this, "User created succssfully", Toast.LENGTH_SHORT).show();
                                            startActivity(new Intent(signup.this, MainActivity.class));
                                            finish();
                                        } else {
                                            Toast.makeText(signup.this, "Failed to create user: " + task.getException(), Toast.LENGTH_SHORT).show();

                                        }

                                    }
                                });

                            }
                        }

                        ;


                    });
        }
    }
}
