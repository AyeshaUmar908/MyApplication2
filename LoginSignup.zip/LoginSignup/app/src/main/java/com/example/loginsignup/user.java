package com.example.loginsignup;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class user {

    public String email, password, confirmpassword;
    public user(){

    }
    public user(String email, String password, String confirmpassword){
        this.email = email;
        this.password = password;
        this.confirmpassword =  confirmpassword;
    }
}
